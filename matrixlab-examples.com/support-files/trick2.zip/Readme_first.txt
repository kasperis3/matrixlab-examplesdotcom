Copyright @ 2009 by www.matrixlab-examples.com
All rights reserved
-------------------------------------------------------------------

In this distribution .zip file there are four files:
- trick2.m
- trick2.fig
- trick2_001.jpg
- trick2_002.jpg

Place all the extracted files in the same directory.
Make that directoty available from Matlab, and on your command 
window type: trick2

