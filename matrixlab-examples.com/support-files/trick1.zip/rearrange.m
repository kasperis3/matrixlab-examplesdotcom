% Copyright 2009 by www.matrixlab-examples.com
function rearrange(c)
global cards

% Take the cards and the column of the selected card 
% is kept as second column
switch c
    case 1
        cards_aux = {cards{:,3} cards{:,1} cards{:,2}};
    case 2
        cards_aux = {cards{:,3} cards{:,2} cards{:,1}};
    otherwise
        cards_aux = {cards{:,2} cards{:,3} cards{:,1}};
end

% Deal the cards with the new order
k = 1;
for i = 1 : 7
    for j = 1 : 3
        cards{i,j} = cards_aux{k};
        k = k + 1;
    end
end
