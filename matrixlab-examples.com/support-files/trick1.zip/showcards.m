% Copyright 2009 by www.matrixlab-examples.com
function showcards()
global ha cards

% Take one .jpg file for each 'axes' (21 cards to deal).
for i = 1 : 21
    axes(ha(i));
    [bg] = imread(strcat(cards{i},'.jpg'));
    image(bg);
    axis off;
end

% Delete the guess
axes(ha(22));
[bg] = imread('gray.jpg');
image(bg);
axis off;