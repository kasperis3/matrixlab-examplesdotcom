Copyright @ 2009 by www.matrixlab-examples.com
All rights reserved
-------------------------------------------------------------------

In this distribution .zip file, there are seven Matlab files:
- trick1.m
- trick1.fig
- initialize_trick.m
- showcards.m
- display_instructions.m
- go_on.m
- rearrange.m

and 53 .jpg files, one for each card in a regular deck plus a 'gray' card.

Place all the files in the same directory.
Make those files available from within Matlab, and on your command window type: trick1

These files have been tested only with Matlab 7.0.1 for Windows XP.
I cannot guarantee that they work under any other platform...
