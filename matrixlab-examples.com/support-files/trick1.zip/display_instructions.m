% Copyright 2009 by www.matrixlab-examples.com
function display_instructions(i)
global ha

% Display instructions according to evolution of trick
switch i
    case 1
        str = {'Step 1: ';
               '';
               'Think of a card and select its column below...'};
        set(ha(23),'String',str);
    case 2
        str = {'Step 2: ';
               '';
               'Hard to guess...';
               '';
               'Could you please select its column again?'};
        set(ha(23),'String',str);
    case 3
        str = {'I cannot see it clearly... ';
               '';
               'Please concentrate and select its column only once more...'};
        set(ha(23),'String',str);
    case 4
        str = '';
        set(ha(23),'String',str);
        str = {'Ah! Got it! ';
               'Your card is: '};
        set(ha(24),'String',str);
end
    