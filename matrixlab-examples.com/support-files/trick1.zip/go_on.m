% Copyright 2009 by www.matrixlab-examples.com
function go_on(hObject,handles,c)
global ha cards

% Take into account the number of choices by the user
handles.t = handles.t + 1;
% Reset the current radio-button
set(hObject,'Value',0);

% Display the cards in a new order.
rearrange(c);
if handles.t < 4   
     showcards();
     display_instructions(handles.t);
else
    % Perform the trick!
    display_instructions(4);
    axes(ha(22));
    [bg] = imread(strcat(cards{4,2},'.jpg'));
    image(bg);
    axis off;
    
    % Make the pushbutton appear
    set(ha(25),'Visible','on')
    
    % Make the radio-buttons disappear
    set(ha(26),'Visible','off')
    set(ha(27),'Visible','off')
    set(ha(28),'Visible','off')
end

guidata(hObject,handles);