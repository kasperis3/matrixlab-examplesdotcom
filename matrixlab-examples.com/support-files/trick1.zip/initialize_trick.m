% Copyright 2009 by www.matrixlab-examples.com
function initialize_trick()
global ha cards

% Define the 52 cards to be used
card_deck = {'ad' 'ah' 'as' 'ac' '2d' '2h' '2s' '2c' ...
             '3d' '3h' '3s' '3c' '4d' '4h' '4s' '4c' ...
             '5d' '5h' '5s' '5c' '6d' '6h' '6s' '6c' ...
             '7d' '7h' '7s' '7c' '8d' '8h' '8s' '8c' ...
             '9d' '9h' '9s' '9c' '10d' '10h' '10s' '10c' ...
             'jd' 'jh' 'js' 'jc' 'qd' 'qh' 'qs' 'qc' ...
             'kd' 'kh' 'ks' 'kc'};
card_nr = 52;

% Select 21 random cards from the deck (7 x 3 matrix)
for i = 1 : 7
    for j = 1 : 3
        % Select one random card from the remaining deck
        r = ceil(card_nr .* rand);
        cards{i,j} = card_deck{r};

        % Delete that card from the deck
        card_deck(r) = [];
        
        % Reduce the card account in the remaining deck
        card_nr = card_nr - 1;
    end
end

% Display cards and first instructions
showcards;
display_instructions(1);  

% Make sure to delete the last guess
str = '';
set(ha(24),'String',str);

% Hide button
set(ha(25),'Visible','off');

% Make the radio-buttons available
set(ha(26),'Visible','on')
set(ha(27),'Visible','on')
set(ha(28),'Visible','on')
